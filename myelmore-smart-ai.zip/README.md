# MyElmore Smart AI

Deployed with Vercel. Handles /api/ask for OpenAI integration.